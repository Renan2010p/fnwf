=== Five Nights With Friends - PS2 Release ===

📀 fnwf-ps2.iso (19 MB) - Imagem ISO com SLUS-20001

📋 Estrutura do CD:
   /FNWF.ELF           - Executável do jogo
   /SYSTEM.CNF         - Configuração de boot
   /ASSETS/FONT/FONT.TTF
   /ASSETS/IMAGES/*.PNG
   /ASSETS/AUDIO/*.OGG

🎮 Disc ID: SLUS-20001
   Brand: Sony Computer Entertainment
   Product: FIVE NIGHTS WITH FRIENDS
   Region: USA (NTSC)

🔥 Para gravar:
   cdrecord -v -dao dev=/dev/sr0 fnwf-ps2.iso

📊 Especificações:
   - Resolução: 640×448 NTSC
   - FPS alvo: 60 FPS (GPU)
   - Busca: cdrom:, usbmass:, mass:
