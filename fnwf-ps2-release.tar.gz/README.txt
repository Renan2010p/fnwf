=== Five Nights With Friends - PS2 Release ===

📀 Arquivos incluídos:
   - fnwf-ps2.iso      (18 MB) - Imagem ISO pronta para gravar
   - build-ps2-iso.sh  - Script para reconstruir a ISO
   - create_ps2_iso.py - Gerador Python de ISO
   - README.txt        - Este arquivo

📋 Estrutura no CD:
   /FNWF.ELF           - Executável do jogo
   /SYSTEM.CNF         - Configuração de boot
   /ASSETS/FONT/FONT.TTF
   /ASSETS/IMAGES/*.PNG
   /ASSETS/AUDIO/*.OGG

🎮 Como usar:
   1. Grave fnwf-ps2.iso em um CD-R (velocidade 4x-12x)
   2. Insira o CD no PS2
   3. O jogo vai bootar automaticamente

📊 Especificações:
   - Resolução: 640×448 (NTSC padrão)
   - FPS alvo: 60 FPS (GPU via gsKit)
   - Busca automática: cdrom:, usbmass:, mass:

⚠️  Nota: 
   - Use CDs-R (não CD-RW)
   - Grave em velocidade baixa (4x máximo)
   - Verifique a gravação após concluir
