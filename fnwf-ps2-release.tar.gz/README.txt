=== Five Nights With Friends - PS2 Release ===

📀 fnwf-ps2.iso (18 MB) - Imagem ISO pronta para gravar
📜 build-ps2-iso.sh - Script de construção
🐍 create_ps2_iso.py - Gerador Python de ISO

📋 Estrutura no CD:
   /FNWF.ELF
   /SYSTEM.CNF
   /ASSETS/FONT/FONT.TTF
   /ASSETS/IMAGES/*.PNG
   /ASSETS/AUDIO/*.OGG

🎮 Para testar no PCSX2:
   File > Open CD/DVD Drive > fnwf-ps2.iso

🔥 Para gravar:
   cdrecord -v -dao dev=/dev/sr0 fnwf-ps2.iso
