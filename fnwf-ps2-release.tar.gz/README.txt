=== Five Nights With Friends - PS2 Release ===

📀 Para PCSX2 (testar primeiro):
   1. Enable Host Filesystem = ON
   2. File > Run ELF... > fnwf.elf
   3. Assets estão na pasta assets/

📀 Para PS2 Real (CD):
   1. Grave fnwf-ps2.iso em um CD-R
   2. Insira no PS2
   3. Jogo boota automaticamente

📋 Estrutura para CD:
   /FNWF.ELF
   /SYSTEM.CNF
   /ASSETS/FONT/FONT.TTF
   /ASSETS/IMAGES/*.PNG
   /ASSETS/AUDIO/*.OGG
