=== Five Nights With Friends - PS2 Release ===

🎮 TESTAR NO PCSX2:
   1. Settings > Emulation > Enable Host Filesystem = ON
   2. File > Run ELF... > fnwf.elf
   3. Assets estão na pasta assets/

📀 PARA PS2 REAL (USB/Mass):
   1. Formate pendrive em FAT32
   2. Crie pasta: /fnwf/
   3. Extraia os arquivos:
      - fnwf.elf
      - assets/ (pasta com todos os assets)
   4. O jogo usa mass:/fnwf/ automaticamente

📋 Estrutura:
   /fnwf/
   ├── fnwf.elf      (16 MB)
   └── assets/
       ├── font/font.ttf
       ├── *.png (imagens)
       └── *.ogg (áudio)

📊 Configurações:
   - Resolução: 640×448 NTSC
   - FPS alvo: 60 FPS (GPU)
   - Device: mass:/fnwf/ (padrão)
