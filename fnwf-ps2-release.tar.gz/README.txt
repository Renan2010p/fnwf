=== Five Nights With Friends - PS2 Release ===

📀 fnwf-ps2.iso (19 MB) - Imagem ISO pronta para gravar

📋 Estrutura no CD:
   /FNWF.ELF
   /SYSTEM.CNF
   /ASSETS/FONT/FONT.TTF
   /ASSETS/IMAGES/*.PNG (6 arquivos)
   /ASSETS/AUDIO/*.OGG (12 arquivos)

🎮 Para testar no PCSX2:
   File > Open CD/DVD Drive > fnwf-ps2.iso

🔥 Para gravar no CD:
   cdrecord -v -dao dev=/dev/sr0 fnwf-ps2.iso

📊 Configurações:
   - Resolução: 640×448 NTSC
   - FPS alvo: 60 FPS (GPU)
   - Busca: cdrom:, usbmass:, mass:
